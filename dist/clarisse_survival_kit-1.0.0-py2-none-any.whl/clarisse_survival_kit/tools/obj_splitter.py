import os
import numpy as np
import pprint


data_keys = ['v', 'vt', 'vn', 'f']


def split_obj(filename=r'C:\Users\Workstation-E5-2696\Downloads\delete me\primitives.obj'):
    if not os.path.exists(filename):
        print 'ERROR: Filename {} does not exist'.format(filename)
        return False
    meshes = []
    with open(filename) as obj_file:
        previous_key = ''
        for line in obj_file:
            if not line.strip():
                continue
            for data_key in data_keys:
                if line.startswith('v ') and previous_key != 'v':
                    meshes.append({})
                    meshes[-1]['sorting'] = 'positive'
                if line.startswith('o '):
                    meshes[-1]['name'] = line.lstrip('o').lstrip().rstrip()
                if line.startswith('g '):
                    meshes[-1]['group'] = line.lstrip('g').lstrip().rstrip()
                if line.startswith(data_key + ' '):
                    data_string = line.lstrip(data_key).lstrip().rstrip()
                    if data_string:
                        data_list = data_string.split(' ')
                        if data_key == 'f':
                            if '/' not in data_string:
                                meshes[-1]['structure'] = 'v'
                                data = map(int, data_list)
                                if data and data[0] < 0:
                                    meshes[-1]['sorting'] = 'negative'
                            elif '//' in data_string:
                                meshes[-1]['structure'] = 'vn'
                                data = [map(int, face.split('//')) for face in data_list]
                                if data and data[0][0] < 0:
                                    meshes[-1]['sorting'] = 'negative'
                            else:
                                data = [map(int, face.split('/')) for face in data_list]
                                if data:
                                    f_indices = len(data[0])
                                    if data and data[0][0] < 0:
                                        meshes[-1]['sorting'] = 'negative'
                                    if f_indices == 2:
                                        meshes[-1]['structure'] = 'vt'
                                    elif f_indices == 3:
                                        meshes[-1]['structure'] = 'vtn'
                        else:
                            data = map(float, data_list)
                        if not meshes[-1].get(data_key):
                            meshes[-1][data_key] = []
                        meshes[-1][data_key].append(data)
                    previous_key = data_key
    pprint.pprint(meshes)
split_obj()
